package com.goktech.lesson10.example;

/**
 * A同学
 * Created by yangbo on 2018/1/29.
 */
public interface LoginService {

    /**
     * 登录方法
     * @param username
     * @param password
     * @return 成功true ,失败false
     */
    public boolean login(String username,String password);


}
