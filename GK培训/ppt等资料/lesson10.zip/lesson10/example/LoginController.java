package com.goktech.lesson10.example;

/** B同学
 * Created by yangbo on 2018/1/29.
 */
public class LoginController {

    private LoginService loginServcie;

    public void login(){
        loginServcie.login("123","123");
    }
}
