package com.goktech.lesson10.example;

/**
 * Created by yangbo on 2018/1/29.
 */
public class LoginServiceImpl implements LoginService {
    @Override
    public boolean login(String username, String password) {
        /**
         * ......
         */
        return false;
    }
}
