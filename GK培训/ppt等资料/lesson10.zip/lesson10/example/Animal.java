package com.goktech.lesson10.example;

/**
 * Created by yangbo on 2018/1/29.
 */
public interface Animal {

    public void bark();

    public void run();
}
