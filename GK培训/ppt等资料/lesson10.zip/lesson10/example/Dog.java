package com.goktech.lesson10.example;

import com.goktech.lesson10.AbstractClass;

/**
 * Created by yangbo on 2018/1/29.
 */
public abstract class Dog implements Animal {

    public void bark(){
        System.out.println("Dog bark();");
    }
}
