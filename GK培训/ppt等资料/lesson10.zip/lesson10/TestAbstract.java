package com.goktech.lesson10;

import com.goktech.lesson09.Bark;
import com.goktech.lesson09.Dog;

/**
 * Created by yangbo on 2018/1/29.
 */
public class TestAbstract {
    public static void main(String[] args){
        AbstractClass abstractClass = new NormalClass() ;
        abstractClass.bark();
    }

}
