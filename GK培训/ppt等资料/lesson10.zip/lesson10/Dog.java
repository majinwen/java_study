package com.goktech.lesson10;

/**
 * Created by yangbo on 2018/1/29.
 */
public class Dog implements TestInterface {

    public void bark(){

    }

    public void run(){

    }
}
