package com.goktech.lesson10;

/**
 * Created by yangbo on 2018/1/29.
 */
public interface TestInterface extends FatherInterface1,FatherInterface2{
    public int a = 10;


    public void bark();

    public void run();
}
