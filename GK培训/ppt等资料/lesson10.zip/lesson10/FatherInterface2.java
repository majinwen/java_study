package com.goktech.lesson10;

/**
 * Created by yangbo on 2018/1/29.
 */
public interface FatherInterface2 {
}
