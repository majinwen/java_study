package com.goktech.lesson10;

/**
 * Created by yangbo on 2018/1/29.
 */
public abstract class AbstractClass {

    protected abstract void bark();        // 抽象方法

    public void print(){
        System.out.println("这是一个普通的方法");
    }
}
