package com.goktech.lesson10;

/**
 * Created by yangbo on 2018/1/29.
 */
public class NormalClass extends AbstractClass {

    public void bark(){
        System.out.println("重写过后的方法");
    }
}
