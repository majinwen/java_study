package class_10.t_3;

public enum WinStr {
    小,中,大
}
