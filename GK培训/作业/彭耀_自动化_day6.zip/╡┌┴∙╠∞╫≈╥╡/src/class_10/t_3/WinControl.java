package class_10.t_3;

/***************************************
 * 风的控制
 *made by pengyao1207
 * create:2018/01/29 20:08
 ***************************************/
public interface WinControl {
    void setWinStr(WinStr winStr);
    WinStr getWinStr();
    void setWinVec(WinVec winVec);
    WinVec getWinVec();
}
