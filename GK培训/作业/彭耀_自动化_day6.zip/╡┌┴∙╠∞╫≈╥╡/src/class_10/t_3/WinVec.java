package class_10.t_3;

public enum WinVec {
    上,下,左,右
}
