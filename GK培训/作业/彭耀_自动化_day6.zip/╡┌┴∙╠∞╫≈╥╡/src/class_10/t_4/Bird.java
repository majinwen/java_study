package class_10.t_4;

/***************************************
 *made by pengyao1207
 * create:2018/01/29 15:42
 ***************************************/
public class Bird implements IFly {
    public void fly() {
        System.out.println("鸟在飞。。");
    }
}
