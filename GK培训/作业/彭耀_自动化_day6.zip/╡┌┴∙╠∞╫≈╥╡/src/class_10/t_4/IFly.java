package class_10.t_4;

public interface IFly {
    void fly();
}
