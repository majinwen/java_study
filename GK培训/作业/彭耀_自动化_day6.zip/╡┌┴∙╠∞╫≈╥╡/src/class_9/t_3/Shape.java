package class_9.t_3;

/***************************************
 *made by pengyao1207
 * create:2018/01/29 16:41
 ***************************************/
public abstract class Shape {
    public abstract void draw(String color);

    public abstract void draw();

    public abstract double getPerimeter();

    public abstract double getArea();
}
