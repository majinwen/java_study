package dayTest;

/***************************************
 *made by pengyao1207
 * create:2018/01/29 15:23
 ***************************************/
public class LoginServiceImpl implements LoginService {
    public boolean login(String username, String passwoed) {
        System.out.println("登陆");
        return false;
    }
}
