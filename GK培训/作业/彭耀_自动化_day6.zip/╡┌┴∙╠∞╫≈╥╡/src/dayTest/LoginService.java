package dayTest;

public interface LoginService {
    boolean login(String username, String passwoed);
}
